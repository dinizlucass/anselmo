import{View, TextInput, TouchableOpacity, Text} from 'react-native'
import mascara from '../css/estilo'

function Soma(){
  alert("Vamos embora!");
}

export default function Calculadora(){
  return(
    <View style={mascara.cx2}>
      <TextInput style={mascara.input} placeholder="Digite o valor 1"/>
      <TextInput style={mascara.input} placeholder="Digite o valor 1"/>
      <TouchableOpacity style={mascara.btn} onPress={Soma}>
        <Text style={mascara.btntexto}>Calcular</Text>
      </TouchableOpacity>
    </View>
)}