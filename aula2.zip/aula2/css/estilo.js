import { StyleSheet, Dimensions } from 'react-native';

// Obtendo as dimensões da tela
const { width } = Dimensions.get('window');

const mascara = StyleSheet.create({
  fundo: {
    flex: 1,
    backgroundColor: '#f00',
    alignItems: 'center', // Alinha o conteúdo no centro horizontalmente
    justifyContent: 'flex-start', // Alinha o conteúdo ao topo
    padding: 10, // Adiciona espaçamento ao redor do contêiner
  },
  titulo: {
    color: '#f00',
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20, // Espaçamento abaixo do título
  },
  containerImagens: {
    flexDirection: 'row', // Alinha as imagens lado a lado
    alignItems: 'flex-start', // Alinha as imagens ao topo
    justifyContent: 'space-between', // Espaço mínimo entre as imagens
    width: '100%', // Usa a largura total do contêiner pai
    maxWidth: 600, // Define um tamanho máximo para o contêiner das imagens
    paddingHorizontal: 10, // Adiciona espaçamento horizontal ao contêiner
  },
  cx1: {
    width: '48%', // Ajusta a largura para que duas imagens caibam lado a lado
    height: 250, // Mantém a altura do contêiner
    borderWidth: 2,
    borderColor: '#0f0',
    borderRadius: 20,
    marginVertical: 10, // Espaçamento vertical para garantir algum espaço em volta
  },
  cx2: {
    width: 300,
    height: 250,
    backgroundColor: '#ccc', // Estilo adicional, mas não está sendo usado no código atual
  },
  input: {
    marginHorizontal: 10,
    marginVertical: 5,
    fontSize: 15,
    borderRadius: 20,
    backgroundColor: '#af8',
    paddingHorizontal: 20,
    paddingVertical: 3,
  },
  fig1: {
    width: '100%', // Ajusta a largura da imagem para preencher o contêiner
    height: '100%', // Ajusta a altura da imagem para preencher o contêiner
    borderRadius: 16,
  },
  fig2: {
    width: '100%', // Ajusta a largura da imagem para preencher o contêiner
    height: '100%', // Ajusta a altura da imagem para preencher o contêiner
    borderRadius: 16,
  },
  btn: {
    marginVertical: 4,
    width: 100,
    height: 20,
    backgroundColor: '#1E90FF',
    borderRadius: 15,
    alignItems: 'center',
    marginLeft: 190,
  },
  btntexto: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },  
});

export default mascara;
