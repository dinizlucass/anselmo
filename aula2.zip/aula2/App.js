import { Text, SafeAreaView, View, Image } from 'react-native';
import mascara from './css/estilo';
import Calculadora from './janelas/calculadora';

export default function App() {
  return (
    <SafeAreaView style={mascara.fundo}>
      <Text style={mascara.titulo}>
        Aula 2
      </Text>
      <View style={mascara.containerImagens}>
        <View style={mascara.cx1}>
          <Image source={require('./img/shadow_sonic.png')} style={mascara.fig1} />
        </View>
        <View style={mascara.cx1}>
          <Image source={require('./img/guarulhos.jpg')} style={mascara.fig2} />
        </View>
      </View>
      <Calculadora />
    </SafeAreaView>
  );
}
